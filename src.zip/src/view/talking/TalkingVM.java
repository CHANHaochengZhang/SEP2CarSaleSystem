package view.talking;

import model.ClientModel;

public class TalkingVM {
    private ClientModel clientModel;

    public TalkingVM(ClientModel clientModel) {
        this.clientModel = clientModel;

    }
}
