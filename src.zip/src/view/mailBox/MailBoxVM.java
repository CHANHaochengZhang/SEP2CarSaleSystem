package view.mailBox;

import model.ClientModel;

public class MailBoxVM {
    private ClientModel clientModel;

    public MailBoxVM(ClientModel clientModel) {
        this.clientModel = clientModel;

    }
}
