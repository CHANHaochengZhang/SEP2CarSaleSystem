package model.carModel;

public interface CarModel {

    void addCar(Car car);

}
