import core.CarSystemApp;
import javafx.application.Application;

public class ClientMain {

    public static void main(String[] args) {
        Application.launch(CarSystemApp.class);
    }
}
